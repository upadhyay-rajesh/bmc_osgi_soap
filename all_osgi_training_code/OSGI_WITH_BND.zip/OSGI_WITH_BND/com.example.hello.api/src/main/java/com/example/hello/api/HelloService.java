package com.example.hello.api;

public interface HelloService {
    String sayHello(String name);
    String createProfile(String name,String password,String email,String address);
    String deleteProfile(String email);
    String editProfile(String email);
    String viewProfile(String email);
}
