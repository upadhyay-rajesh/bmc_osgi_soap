package com.example.hello.consumer;

import java.util.Scanner;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;
import com.example.hello.api.HelloService;

public class Activator implements BundleActivator {
    private ServiceTracker<HelloService, HelloService> tracker;

    @Override
    public void start(BundleContext context) throws Exception {
        System.out.println("[hello-consumer] Looking for HelloService...");
        tracker = new ServiceTracker<>(context, HelloService.class, null);
        tracker.open();

        HelloService svc = tracker.waitForService(5000); // instead of 2000

        if (svc != null) {
        	Scanner sc=new Scanner(System.in);
        	String str="y";
        	while(str.equals("y")) {
        	System.out.println("**************MAIN MENU***************");
        	System.out.println("press 1 to create profile");
        	System.out.println("press 2 to delete profile");
        	System.out.println("press 3 to edit profile");
        	System.out.println("press 4 to view profile");
        	System.out.println("press 5 to say hello");
        	System.out.println("enter choice");
        	int c=sc.nextInt();
        	switch(c) {
        	case 1: System.out.println(svc.createProfile("Rajesh", "abcd", "upadhyay.rajesh@rediffmail.com", "Bangalore"));
        		break;
        	case 2: System.out.println(svc.deleteProfile("upadhyay.rajesh@rediffmail.com"));
        		break;
        	case 3: System.out.println(svc.editProfile("upadhyay.rajesh@rediffmail.com"));
        		break;
        	case 4:System.out.println(svc.viewProfile("upadhyay.rajesh@rediffmail.com"));
        		break;
        	case 5:System.out.println("[hello-consumer] Got: " + svc.sayHello("Rajesh"));
        		break;
        		default:System.out.println("wrong choice");
        	}
        	System.out.println("do you want to continue press y or n");
        	str=sc.next();
        	}
            
        } else {
            System.out.println("[hello-consumer] Service not available");
        }
    }

    @Override
    public void stop(BundleContext context) throws Exception {
        tracker.close();
        System.out.println("[hello-consumer] Stopped");
    }
}
