package com.example.hello.impl;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import com.example.hello.api.HelloService;

public class Activator implements BundleActivator {
    private ServiceRegistration<HelloService> reg;

    @Override
    public void start(BundleContext context) {
        HelloService svc = new HelloServiceImpl();
        reg = context.registerService(HelloService.class, svc, null);
        System.out.println("[hello-impl] HelloService registered");
    }

    @Override
    public void stop(BundleContext context) {
        if (reg != null) reg.unregister();
        System.out.println("[hello-impl] HelloService unregistered");
    }
}
