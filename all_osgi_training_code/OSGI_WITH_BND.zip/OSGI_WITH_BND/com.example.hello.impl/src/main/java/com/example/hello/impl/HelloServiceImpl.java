package com.example.hello.impl;

import com.example.hello.api.HelloService;

public class HelloServiceImpl implements HelloService {
    @Override
    public String sayHello(String name) {
        return "Hello, " + name + " (from Impl)";
    }

	@Override
	public String createProfile(String name, String password, String email, String address) {
		// TODO Auto-generated method stub
		return "profile created and details is "+name+"  "+password+"  "+email+"   "+address;
	}

	@Override
	public String deleteProfile(String email) {
		// TODO Auto-generated method stub
		return "profile deleted for "+email;
	}

	@Override
	public String editProfile(String email) {
		// TODO Auto-generated method stub
		return "profile edited for "+email;
	}

	@Override
	public String viewProfile(String email) {
		// TODO Auto-generated method stub
		return "profile viewed for "+email;
	}
}
